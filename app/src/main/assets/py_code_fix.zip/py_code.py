# -*- coding: utf-8 -*-
# !/usr/bin/python3
# @File    : py_code.py
# @Date    : 2022-03-26
# @Author  : xxxxxxH

import requests


def get_interactive_data(url: str):
    result = ""
    r = requests.get(url=url, timeout=10, verify=False)
    if r.status_code == 200:
        result = r.text.encode('utf8', 'ignore')
    print(result)
    return result


def get_details_data(url: str):
    result = ""
    r = requests.get(url=url, timeout=10, verify=False)
    if r.status_code == 200:
        result = r.text.encode('utf8', 'ignore')
    print(result)
    return result

